import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { TeacherShell } from "@/components/TeacherShell";
import { DAY_LABELS } from "@/lib/types";

export default async function DashboardPage() {
  const supabase = await createClient();
  const today = new Date().toISOString().slice(0, 10);

  const [{ count: studentCount }, { data: todayAttendance }, { data: upcomingSlots }] =
    await Promise.all([
      supabase.from("students").select("*", { count: "exact", head: true }),
      supabase.from("attendance").select("status").eq("date", today),
      supabase.from("schedule_slots").select("*").order("day_of_week").order("start_time"),
    ]);

  const unexcused = (todayAttendance ?? []).filter((a) => a.status === "unexcused").length;
  const excused = (todayAttendance ?? []).filter((a) => a.status === "excused").length;
  const takenToday = (todayAttendance ?? []).length > 0;

  return (
    <TeacherShell>
      <h1 className="mb-1 font-display text-3xl text-pine">Tổng quan</h1>
      <p className="mb-8 text-ink-soft">
        Hôm nay,{" "}
        {new Date().toLocaleDateString("vi-VN", {
          weekday: "long",
          day: "2-digit",
          month: "2-digit",
          year: "numeric",
        })}
      </p>

      <div className="mb-10 grid grid-cols-1 gap-4 sm:grid-cols-3">
        <div className="notebook-rule border-pine bg-white/60 p-5">
          <p className="text-sm text-ink-soft">Sĩ số lớp</p>
          <p className="font-display text-3xl text-pine">{studentCount ?? 0}</p>
        </div>
        <div className="notebook-rule border-marigold bg-white/60 p-5">
          <p className="text-sm text-ink-soft">Điểm danh hôm nay</p>
          <p className="font-display text-3xl text-marigold-deep">
            {takenToday ? "Đã điểm danh" : "Chưa điểm danh"}
          </p>
        </div>
        <div className="notebook-rule border-coral bg-white/60 p-5">
          <p className="text-sm text-ink-soft">Vắng hôm nay</p>
          <p className="font-display text-3xl text-coral">
            {excused + unexcused}{" "}
            <span className="text-base font-normal text-ink-soft">
              ({unexcused} không phép)
            </span>
          </p>
        </div>
      </div>

      <div className="mb-4 flex items-center justify-between">
        <h2 className="font-display text-xl text-pine">Thời khoá biểu tuần này</h2>
        <Link href="/thoi-khoa-bieu" className="text-sm text-pine underline">
          Chỉnh sửa
        </Link>
      </div>

      {upcomingSlots && upcomingSlots.length > 0 ? (
        <ul className="divide-y divide-paper-line border border-paper-line bg-white/60">
          {upcomingSlots.map((slot) => (
            <li key={slot.id} className="flex items-center justify-between px-4 py-3 text-sm">
              <span className="font-medium text-ink">{DAY_LABELS[slot.day_of_week]}</span>
              <span className="text-ink-soft">
                {slot.start_time.slice(0, 5)}–{slot.end_time.slice(0, 5)}
              </span>
              <span className="text-ink">{slot.subject}</span>
            </li>
          ))}
        </ul>
      ) : (
        <p className="border border-dashed border-paper-line px-4 py-6 text-center text-sm text-ink-soft">
          Chưa có thời khoá biểu. Vào mục &quot;Thời khoá biểu&quot; để thêm tiết học.
        </p>
      )}
    </TeacherShell>
  );
}

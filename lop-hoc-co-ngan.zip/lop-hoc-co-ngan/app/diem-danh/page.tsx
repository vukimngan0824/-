import { createClient } from "@/lib/supabase/server";
import { TeacherShell } from "@/components/TeacherShell";
import { AttendanceGrid } from "@/components/AttendanceGrid";
import type { AttendanceStatus } from "@/lib/types";

export default async function AttendancePage({
  searchParams,
}: {
  searchParams: Promise<{ date?: string }>;
}) {
  const { date: dateParam } = await searchParams;
  const date = dateParam || new Date().toISOString().slice(0, 10);

  const supabase = await createClient();
  const [{ data: students }, { data: attendance }] = await Promise.all([
    supabase.from("students").select("*").order("full_name"),
    supabase.from("attendance").select("*").eq("date", date),
  ]);

  const initialStatuses: Record<string, AttendanceStatus> = {};
  (attendance ?? []).forEach((a) => {
    initialStatuses[a.student_id] = a.status;
  });

  return (
    <TeacherShell>
      <h1 className="mb-1 font-display text-3xl text-pine">Điểm danh</h1>
      <p className="mb-6 text-ink-soft">Chọn ngày và đánh dấu tình trạng từng học sinh.</p>

      <form method="get" className="mb-6 flex items-center gap-3">
        <input
          type="date"
          name="date"
          defaultValue={date}
          className="border border-paper-line bg-white px-3 py-2 outline-none focus:border-pine"
        />
        <button type="submit" className="border border-pine px-4 py-2 text-pine hover:bg-pine hover:text-paper">
          Xem ngày này
        </button>
      </form>

      {students && students.length > 0 ? (
        <AttendanceGrid date={date} students={students} initialStatuses={initialStatuses} />
      ) : (
        <p className="border border-dashed border-paper-line px-4 py-6 text-center text-sm text-ink-soft">
          Chưa có học sinh nào trong lớp. Thêm học sinh ở mục &quot;Học sinh&quot; trước.
        </p>
      )}
    </TeacherShell>
  );
}

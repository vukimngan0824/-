import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { TeacherShell } from "@/components/TeacherShell";
import { StudentForm } from "@/components/StudentForm";
import { GradeForm } from "@/components/GradeForm";
import { CopyLinkButton } from "@/components/CopyLinkButton";
import { DeleteButton } from "@/components/DeleteButton";
import { updateStudent, deleteStudent } from "@/lib/actions/students";
import { deleteGrade } from "@/lib/actions/grades";
import { ATTENDANCE_LABELS, type AttendanceStatus } from "@/lib/types";
import { redirect } from "next/navigation";

export default async function StudentDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const supabase = await createClient();

  const [{ data: student }, { data: grades }, { data: attendance }] = await Promise.all([
    supabase.from("students").select("*").eq("id", id).single(),
    supabase
      .from("grades")
      .select("*")
      .eq("student_id", id)
      .order("entry_date", { ascending: false }),
    supabase
      .from("attendance")
      .select("*")
      .eq("student_id", id)
      .order("date", { ascending: false })
      .limit(31),
  ]);

  if (!student) {
    notFound();
  }

  const boundUpdate = updateStudent.bind(null, id);
  const boundDelete = deleteStudent.bind(null, id);

  const unexcusedCount = (attendance ?? []).filter((a) => a.status === "unexcused").length;

  return (
    <TeacherShell>
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <h1 className="font-display text-3xl text-pine">{student.full_name}</h1>
        <div className="flex items-center gap-3">
          <CopyLinkButton code={student.access_code} />
          <DeleteButton
            action={async () => {
              "use server";
              await boundDelete();
              redirect("/hoc-sinh");
            }}
            confirmMessage={`Xoá học sinh "${student.full_name}"? Toàn bộ điểm và điểm danh liên quan sẽ bị xoá.`}
          />
        </div>
      </div>

      <section className="mb-10 border border-paper-line bg-white/60 p-5">
        <h2 className="mb-4 font-display text-lg text-pine">Thông tin học sinh</h2>
        <StudentForm student={student} action={boundUpdate} submitLabel="Lưu thay đổi" />
      </section>

      <section className="mb-10 notebook-rule border-marigold bg-white/60 p-5">
        <h2 className="mb-1 font-display text-lg text-pine">Điểm danh gần đây</h2>
        <p className="mb-4 text-sm text-ink-soft">
          {unexcusedCount > 0
            ? `${unexcusedCount} buổi vắng không phép trong 31 ngày gần nhất.`
            : "Không có buổi vắng không phép trong 31 ngày gần nhất."}
        </p>
        {attendance && attendance.length > 0 ? (
          <ul className="flex flex-wrap gap-2">
            {attendance.map((a) => (
              <li
                key={a.id}
                className={`border px-2 py-1 text-xs ${
                  a.status === "present"
                    ? "border-pine/30 text-pine"
                    : a.status === "excused"
                    ? "border-marigold-deep/40 text-marigold-deep"
                    : "border-coral/40 text-coral"
                }`}
                title={ATTENDANCE_LABELS[a.status as AttendanceStatus]}
              >
                {new Date(a.date).toLocaleDateString("vi-VN", {
                  day: "2-digit",
                  month: "2-digit",
                })}
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-sm text-ink-soft">Chưa có dữ liệu điểm danh.</p>
        )}
      </section>

      <section className="border border-paper-line bg-white/60 p-5">
        <h2 className="mb-4 font-display text-lg text-pine">Điểm &amp; nhận xét</h2>
        <GradeForm studentId={id} />

        {grades && grades.length > 0 ? (
          <ul className="mt-6 divide-y divide-paper-line">
            {grades.map((g) => (
              <li key={g.id} className="flex items-start justify-between gap-3 py-3">
                <div>
                  <p className="text-sm text-ink-soft">
                    {new Date(g.entry_date).toLocaleDateString("vi-VN")}
                    {g.subject ? ` · ${g.subject}` : ""}
                    {g.score !== null ? ` · Điểm: ${g.score}` : ""}
                  </p>
                  {g.note && <p className="text-ink">{g.note}</p>}
                </div>
                <DeleteButton
                  action={async () => {
                    "use server";
                    await deleteGrade(g.id, id);
                  }}
                  confirmMessage="Xoá mục điểm/nhận xét này?"
                />
              </li>
            ))}
          </ul>
        ) : (
          <p className="mt-6 text-sm text-ink-soft">Chưa có điểm hoặc nhận xét nào.</p>
        )}
      </section>
    </TeacherShell>
  );
}

import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { TeacherShell } from "@/components/TeacherShell";
import { StudentForm } from "@/components/StudentForm";
import { CopyLinkButton } from "@/components/CopyLinkButton";
import { createStudent } from "@/lib/actions/students";

export default async function StudentsPage() {
  const supabase = await createClient();
  const { data: students } = await supabase
    .from("students")
    .select("*")
    .order("full_name");

  return (
    <TeacherShell>
      <h1 className="mb-1 font-display text-3xl text-pine">Học sinh</h1>
      <p className="mb-8 text-ink-soft">
        Quản lý danh sách lớp và lấy link riêng để gửi phụ huynh qua Zalo.
      </p>

      <details className="mb-8 border border-paper-line bg-white/60 p-5">
        <summary className="cursor-pointer font-display text-lg text-pine">
          + Thêm học sinh mới
        </summary>
        <div className="mt-4">
          <StudentForm action={createStudent} submitLabel="Thêm học sinh" />
        </div>
      </details>

      {students && students.length > 0 ? (
        <ul className="space-y-3">
          {students.map((s) => (
            <li
              key={s.id}
              className="flex flex-col gap-3 border border-paper-line bg-white/60 p-4 sm:flex-row sm:items-center sm:justify-between"
            >
              <div>
                <Link
                  href={`/hoc-sinh/${s.id}`}
                  className="font-display text-lg text-pine hover:underline"
                >
                  {s.full_name}
                </Link>
                <p className="text-sm text-ink-soft">
                  {s.parent_name ? `PH: ${s.parent_name}` : "Chưa có tên phụ huynh"}
                  {s.parent_phone ? ` · ${s.parent_phone}` : ""}
                </p>
              </div>
              <CopyLinkButton code={s.access_code} />
            </li>
          ))}
        </ul>
      ) : (
        <p className="border border-dashed border-paper-line px-4 py-6 text-center text-sm text-ink-soft">
          Chưa có học sinh nào. Thêm học sinh đầu tiên ở form phía trên.
        </p>
      )}
    </TeacherShell>
  );
}

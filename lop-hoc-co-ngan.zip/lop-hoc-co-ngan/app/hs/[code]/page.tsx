import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import {
  ATTENDANCE_LABELS,
  DAY_LABELS,
  type PublicStudentInfo,
} from "@/lib/types";

function monthKey(dateStr: string) {
  return dateStr.slice(0, 7); // YYYY-MM
}

export default async function ParentStudentPage({
  params,
  searchParams,
}: {
  params: Promise<{ code: string }>;
  searchParams: Promise<{ thang?: string }>;
}) {
  const { code } = await params;
  const { thang } = await searchParams;

  const supabase = await createClient();
  const { data, error } = await supabase.rpc("get_public_student_info", { code });

  if (error || !data) {
    notFound();
  }

  const info = data as PublicStudentInfo;
  const currentMonth = thang || new Date().toISOString().slice(0, 7);

  const monthsAvailable = Array.from(
    new Set([
      ...info.attendance.map((a) => monthKey(a.date)),
      ...info.grades.map((g) => monthKey(g.entry_date)),
      currentMonth,
    ])
  ).sort((a, b) => b.localeCompare(a));

  const attendanceThisMonth = info.attendance
    .filter((a) => monthKey(a.date) === currentMonth)
    .sort((a, b) => a.date.localeCompare(b.date));

  const gradesThisMonth = info.grades
    .filter((g) => monthKey(g.entry_date) === currentMonth)
    .sort((a, b) => a.entry_date.localeCompare(b.entry_date));

  const unexcused = attendanceThisMonth.filter((a) => a.status === "unexcused").length;
  const excused = attendanceThisMonth.filter((a) => a.status === "excused").length;
  const present = attendanceThisMonth.filter((a) => a.status === "present").length;

  return (
    <div className="min-h-screen bg-paper px-4 py-10">
      <div className="mx-auto max-w-2xl">
        <header className="mb-10 border-b-4 border-marigold pb-6 text-center">
          <p className="text-sm uppercase tracking-wide text-ink-soft">Lớp học cô Ngân</p>
          <h1 className="mt-2 font-display text-3xl text-pine">{info.full_name}</h1>
          {info.parent_name && (
            <p className="mt-1 text-ink-soft">Phụ huynh: {info.parent_name}</p>
          )}
        </header>

        <form method="get" className="mb-8 flex items-center justify-center gap-3">
          <label htmlFor="thang" className="text-sm text-ink-soft">
            Xem theo tháng:
          </label>
          <select
            id="thang"
            name="thang"
            defaultValue={currentMonth}
            className="border border-paper-line bg-white px-3 py-1.5 text-sm outline-none focus:border-pine"
          >
            {monthsAvailable.map((m) => (
              <option key={m} value={m}>
                {m}
              </option>
            ))}
          </select>
          <button
            type="submit"
            className="border border-pine px-3 py-1.5 text-sm text-pine hover:bg-pine hover:text-paper"
          >
            Xem
          </button>
        </form>

        <section className="mb-10">
          <h2 className="mb-3 font-display text-xl text-pine">
            Chuyên cần tháng {currentMonth}
          </h2>
          <div className="mb-4 grid grid-cols-3 gap-3 text-center text-sm">
            <div className="border border-paper-line bg-white/60 py-3">
              <p className="font-display text-2xl text-pine">{present}</p>
              <p className="text-ink-soft">Có mặt</p>
            </div>
            <div className="border border-paper-line bg-white/60 py-3">
              <p className="font-display text-2xl text-marigold-deep">{excused}</p>
              <p className="text-ink-soft">Có phép</p>
            </div>
            <div className="border border-paper-line bg-white/60 py-3">
              <p className="font-display text-2xl text-coral">{unexcused}</p>
              <p className="text-ink-soft">Không phép</p>
            </div>
          </div>
          {attendanceThisMonth.length > 0 ? (
            <ul className="flex flex-wrap gap-2">
              {attendanceThisMonth.map((a) => (
                <li
                  key={a.id}
                  className={`border px-2 py-1 text-xs ${
                    a.status === "present"
                      ? "border-pine/30 text-pine"
                      : a.status === "excused"
                      ? "border-marigold-deep/40 text-marigold-deep"
                      : "border-coral/40 text-coral"
                  }`}
                  title={ATTENDANCE_LABELS[a.status]}
                >
                  {new Date(a.date).toLocaleDateString("vi-VN", {
                    day: "2-digit",
                    month: "2-digit",
                  })}
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-sm text-ink-soft">Chưa có dữ liệu điểm danh tháng này.</p>
          )}
        </section>

        <section className="mb-10">
          <h2 className="mb-3 font-display text-xl text-pine">
            Điểm &amp; nhận xét tháng {currentMonth}
          </h2>
          {gradesThisMonth.length > 0 ? (
            <ul className="divide-y divide-paper-line border border-paper-line bg-white/60">
              {gradesThisMonth.map((g) => (
                <li key={g.id} className="px-4 py-3">
                  <p className="text-sm text-ink-soft">
                    {new Date(g.entry_date).toLocaleDateString("vi-VN")}
                    {g.subject ? ` · ${g.subject}` : ""}
                    {g.score !== null ? ` · Điểm: ${g.score}` : ""}
                  </p>
                  {g.note && <p className="text-ink">{g.note}</p>}
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-sm text-ink-soft">Chưa có điểm hoặc nhận xét tháng này.</p>
          )}
        </section>

        <section>
          <h2 className="mb-3 font-display text-xl text-pine">Thời khoá biểu lớp</h2>
          {info.schedule.length > 0 ? (
            <ul className="divide-y divide-paper-line border border-paper-line bg-white/60">
              {info.schedule.map((s) => (
                <li key={s.id} className="flex items-center justify-between px-4 py-3 text-sm">
                  <span className="w-20 font-medium text-ink">{DAY_LABELS[s.day_of_week]}</span>
                  <span className="text-ink-soft">
                    {s.start_time.slice(0, 5)}–{s.end_time.slice(0, 5)}
                  </span>
                  <span className="text-ink">{s.subject}</span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-sm text-ink-soft">Chưa có thời khoá biểu.</p>
          )}
        </section>
      </div>
    </div>
  );
}

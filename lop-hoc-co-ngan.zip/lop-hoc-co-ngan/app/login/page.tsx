"use client";

import { useActionState } from "react";
import { login } from "@/lib/actions/auth";

type State = { error: string | null };

export default function LoginPage() {
  const [state, formAction, pending] = useActionState<State, FormData>(
    async (_prev, formData) => {
      const result = await login(formData);
      return result ?? { error: null };
    },
    { error: null }
  );

  return (
    <div className="flex min-h-screen items-center justify-center bg-paper px-4">
      <div className="w-full max-w-sm">
        <div className="mb-8 text-center">
          <p className="font-display text-2xl text-pine">Lớp học</p>
          <p className="font-display text-2xl text-marigold-deep">cô Ngân</p>
          <p className="mt-2 text-sm text-ink-soft">Đăng nhập để quản lý lớp học</p>
        </div>

        <form action={formAction} className="space-y-4 border-t-4 border-marigold bg-white/60 p-6">
          <div>
            <label htmlFor="email" className="mb-1 block text-sm text-ink-soft">
              Email
            </label>
            <input
              id="email"
              name="email"
              type="email"
              required
              autoComplete="email"
              className="w-full border border-paper-line bg-white px-3 py-2 text-ink outline-none focus:border-pine"
            />
          </div>
          <div>
            <label htmlFor="password" className="mb-1 block text-sm text-ink-soft">
              Mật khẩu
            </label>
            <input
              id="password"
              name="password"
              type="password"
              required
              autoComplete="current-password"
              className="w-full border border-paper-line bg-white px-3 py-2 text-ink outline-none focus:border-pine"
            />
          </div>

          {state.error && (
            <p className="border-l-4 border-coral bg-coral/10 px-3 py-2 text-sm text-coral">
              {state.error}
            </p>
          )}

          <button
            type="submit"
            disabled={pending}
            className="w-full bg-pine px-4 py-2 font-medium text-paper transition-colors hover:bg-pine-deep disabled:opacity-60"
          >
            {pending ? "Đang đăng nhập..." : "Đăng nhập"}
          </button>
        </form>

        <p className="mt-4 text-center text-xs text-ink-soft">
          Tài khoản được tạo trong Supabase Dashboard — xem hướng dẫn ở README.
        </p>
      </div>
    </div>
  );
}

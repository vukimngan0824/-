import { createClient } from "@/lib/supabase/server";
import { TeacherShell } from "@/components/TeacherShell";
import { ScheduleForm } from "@/components/ScheduleForm";
import { DeleteButton } from "@/components/DeleteButton";
import { deleteScheduleSlot } from "@/lib/actions/schedule";
import { DAY_LABELS } from "@/lib/types";

export default async function SchedulePage() {
  const supabase = await createClient();
  const { data: slots } = await supabase
    .from("schedule_slots")
    .select("*")
    .order("day_of_week")
    .order("start_time");

  return (
    <TeacherShell>
      <h1 className="mb-1 font-display text-3xl text-pine">Thời khoá biểu</h1>
      <p className="mb-6 text-ink-soft">
        Thời khoá biểu chung của lớp — phụ huynh cũng sẽ thấy mục này trong trang riêng của con.
      </p>

      <div className="mb-8 border border-paper-line bg-white/60 p-5">
        <ScheduleForm />
      </div>

      {slots && slots.length > 0 ? (
        <ul className="divide-y divide-paper-line border border-paper-line bg-white/60">
          {slots.map((slot) => (
            <li key={slot.id} className="flex items-center justify-between px-4 py-3 text-sm">
              <span className="w-20 font-medium text-ink">{DAY_LABELS[slot.day_of_week]}</span>
              <span className="text-ink-soft">
                {slot.start_time.slice(0, 5)}–{slot.end_time.slice(0, 5)}
              </span>
              <span className="flex-1 px-4 text-ink">{slot.subject}</span>
              <DeleteButton
                action={async () => {
                  "use server";
                  await deleteScheduleSlot(slot.id);
                }}
                confirmMessage={`Xoá tiết "${slot.subject}"?`}
              />
            </li>
          ))}
        </ul>
      ) : (
        <p className="border border-dashed border-paper-line px-4 py-6 text-center text-sm text-ink-soft">
          Chưa có tiết học nào. Thêm ở form phía trên.
        </p>
      )}
    </TeacherShell>
  );
}

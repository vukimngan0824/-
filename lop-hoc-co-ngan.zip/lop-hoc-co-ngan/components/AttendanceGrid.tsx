"use client";

import { useState, useTransition } from "react";
import { saveAttendanceForDate } from "@/lib/actions/attendance";
import type { AttendanceStatus, Student } from "@/lib/types";
import { ATTENDANCE_LABELS } from "@/lib/types";

const STATUSES: AttendanceStatus[] = ["present", "excused", "unexcused"];

const STATUS_STYLE: Record<AttendanceStatus, string> = {
  present: "border-pine text-pine data-[active=true]:bg-pine data-[active=true]:text-paper",
  excused:
    "border-marigold-deep text-marigold-deep data-[active=true]:bg-marigold-deep data-[active=true]:text-paper",
  unexcused: "border-coral text-coral data-[active=true]:bg-coral data-[active=true]:text-paper",
};

export function AttendanceGrid({
  date,
  students,
  initialStatuses,
}: {
  date: string;
  students: Student[];
  initialStatuses: Record<string, AttendanceStatus>;
}) {
  const [statuses, setStatuses] = useState<Record<string, AttendanceStatus>>(initialStatuses);
  const [isPending, startTransition] = useTransition();
  const [saved, setSaved] = useState(false);

  function setAll(status: AttendanceStatus) {
    const next: Record<string, AttendanceStatus> = {};
    students.forEach((s) => (next[s.id] = status));
    setStatuses(next);
  }

  function handleSave() {
    setSaved(false);
    startTransition(async () => {
      const entries = students.map((s) => ({
        student_id: s.id,
        status: statuses[s.id] ?? "present",
      }));
      const result = await saveAttendanceForDate(date, entries);
      if (!result.error) setSaved(true);
    });
  }

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-center gap-2 text-sm">
        <span className="text-ink-soft">Đánh dấu nhanh cả lớp:</span>
        {STATUSES.map((status) => (
          <button
            key={status}
            type="button"
            onClick={() => setAll(status)}
            className={`border px-3 py-1 ${STATUS_STYLE[status]}`}
          >
            {ATTENDANCE_LABELS[status]}
          </button>
        ))}
      </div>

      <ul className="divide-y divide-paper-line border border-paper-line bg-white/60">
        {students.map((s) => (
          <li key={s.id} className="flex flex-col gap-2 px-4 py-3 sm:flex-row sm:items-center sm:justify-between">
            <span className="font-medium text-ink">{s.full_name}</span>
            <div className="flex gap-2">
              {STATUSES.map((status) => (
                <button
                  key={status}
                  type="button"
                  data-active={statuses[s.id] === status}
                  onClick={() => setStatuses((prev) => ({ ...prev, [s.id]: status }))}
                  className={`border px-3 py-1 text-xs ${STATUS_STYLE[status]}`}
                >
                  {ATTENDANCE_LABELS[status]}
                </button>
              ))}
            </div>
          </li>
        ))}
      </ul>

      <div className="mt-4 flex items-center gap-3">
        <button
          type="button"
          onClick={handleSave}
          disabled={isPending || students.length === 0}
          className="bg-pine px-5 py-2 font-medium text-paper transition-colors hover:bg-pine-deep disabled:opacity-60"
        >
          {isPending ? "Đang lưu..." : "Lưu điểm danh"}
        </button>
        {saved && <span className="text-sm text-pine">Đã lưu điểm danh ngày {date}.</span>}
      </div>
    </div>
  );
}

"use client";

import { useState } from "react";

export function CopyLinkButton({ code }: { code: string }) {
  const [copied, setCopied] = useState(false);

  async function handleCopy() {
    const url = `${window.location.origin}/hs/${code}`;
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Trình duyệt chặn clipboard — bỏ qua, người dùng có thể copy thủ công.
    }
  }

  return (
    <button
      type="button"
      onClick={handleCopy}
      className="border border-pine px-3 py-1 text-xs text-pine transition-colors hover:bg-pine hover:text-paper"
    >
      {copied ? "Đã copy!" : "Copy link phụ huynh"}
    </button>
  );
}

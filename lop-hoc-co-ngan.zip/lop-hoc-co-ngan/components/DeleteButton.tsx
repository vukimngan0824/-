"use client";

export function DeleteButton({
  action,
  confirmMessage,
  label = "Xoá",
}: {
  action: () => Promise<unknown>;
  confirmMessage: string;
  label?: string;
}) {
  return (
    <form
      action={async () => {
        if (window.confirm(confirmMessage)) {
          await action();
        }
      }}
    >
      <button type="submit" className="text-xs text-coral underline">
        {label}
      </button>
    </form>
  );
}

"use client";

import { useActionState } from "react";
import { addGrade } from "@/lib/actions/grades";

type State = { error: string | null };

export function GradeForm({ studentId }: { studentId: string }) {
  const [state, formAction, pending] = useActionState<State, FormData>(
    async (_prev, formData) => addGrade(studentId, formData),
    { error: null }
  );

  return (
    <form action={formAction} className="grid grid-cols-1 gap-3 sm:grid-cols-4">
      <input
        name="subject"
        placeholder="Môn học"
        className="border border-paper-line bg-white px-3 py-2 outline-none focus:border-pine sm:col-span-1"
      />
      <input
        name="score"
        type="number"
        step="0.1"
        min="0"
        max="10"
        placeholder="Điểm"
        className="border border-paper-line bg-white px-3 py-2 outline-none focus:border-pine sm:col-span-1"
      />
      <input
        name="entry_date"
        type="date"
        defaultValue={new Date().toISOString().slice(0, 10)}
        className="border border-paper-line bg-white px-3 py-2 outline-none focus:border-pine sm:col-span-1"
      />
      <input
        name="note"
        placeholder="Nhận xét"
        className="border border-paper-line bg-white px-3 py-2 outline-none focus:border-pine sm:col-span-1"
      />
      {state.error && (
        <p className="sm:col-span-4 border-l-4 border-coral bg-coral/10 px-3 py-2 text-sm text-coral">
          {state.error}
        </p>
      )}
      <div className="sm:col-span-4">
        <button
          type="submit"
          disabled={pending}
          className="bg-marigold px-4 py-2 font-medium text-ink transition-colors hover:bg-marigold-deep disabled:opacity-60"
        >
          {pending ? "Đang lưu..." : "Thêm điểm / nhận xét"}
        </button>
      </div>
    </form>
  );
}

"use client";

import { useActionState } from "react";
import { addScheduleSlot } from "@/lib/actions/schedule";
import { DAY_LABELS } from "@/lib/types";

type State = { error: string | null };

export function ScheduleForm() {
  const [state, formAction, pending] = useActionState<State, FormData>(
    async (_prev, formData) => addScheduleSlot(formData),
    { error: null }
  );

  return (
    <form action={formAction} className="grid grid-cols-1 gap-3 sm:grid-cols-5">
      <select
        name="day_of_week"
        required
        defaultValue=""
        className="border border-paper-line bg-white px-3 py-2 outline-none focus:border-pine"
      >
        <option value="" disabled>
          Thứ
        </option>
        {Object.entries(DAY_LABELS).map(([value, label]) => (
          <option key={value} value={value}>
            {label}
          </option>
        ))}
      </select>
      <input
        type="time"
        name="start_time"
        required
        className="border border-paper-line bg-white px-3 py-2 outline-none focus:border-pine"
      />
      <input
        type="time"
        name="end_time"
        required
        className="border border-paper-line bg-white px-3 py-2 outline-none focus:border-pine"
      />
      <input
        name="subject"
        placeholder="Môn học"
        required
        className="border border-paper-line bg-white px-3 py-2 outline-none focus:border-pine"
      />
      <button
        type="submit"
        disabled={pending}
        className="bg-pine px-4 py-2 font-medium text-paper transition-colors hover:bg-pine-deep disabled:opacity-60"
      >
        {pending ? "Đang lưu..." : "Thêm tiết"}
      </button>
      {state.error && (
        <p className="sm:col-span-5 border-l-4 border-coral bg-coral/10 px-3 py-2 text-sm text-coral">
          {state.error}
        </p>
      )}
    </form>
  );
}

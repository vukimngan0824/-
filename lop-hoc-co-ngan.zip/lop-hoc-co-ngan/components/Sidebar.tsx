"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { logout } from "@/lib/actions/auth";

const LINKS = [
  { href: "/dashboard", label: "Tổng quan" },
  { href: "/hoc-sinh", label: "Học sinh" },
  { href: "/diem-danh", label: "Điểm danh" },
  { href: "/thoi-khoa-bieu", label: "Thời khoá biểu" },
];

export function Sidebar() {
  const activePath = usePathname();
  return (
    <aside className="flex h-full w-56 shrink-0 flex-col justify-between bg-pine text-paper">
      <div>
        <div className="px-6 py-8">
          <p className="font-display text-xl leading-tight">Lớp học</p>
          <p className="font-display text-xl leading-tight text-marigold">cô Ngân</p>
        </div>
        <nav className="flex flex-col">
          {LINKS.map((link) => {
            const isActive = activePath.startsWith(link.href);
            return (
              <Link
                key={link.href}
                href={link.href}
                className={`border-l-4 px-6 py-3 text-sm transition-colors ${
                  isActive
                    ? "border-marigold bg-pine-deep font-medium text-paper"
                    : "border-transparent text-paper/70 hover:border-marigold/50 hover:text-paper"
                }`}
              >
                {link.label}
              </Link>
            );
          })}
        </nav>
      </div>
      <form action={logout} className="px-6 py-6">
        <button className="text-sm text-paper/60 hover:text-paper" type="submit">
          Đăng xuất
        </button>
      </form>
    </aside>
  );
}

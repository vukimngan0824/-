"use client";

import { useActionState } from "react";
import type { Student } from "@/lib/types";

type State = { error: string | null };
type Action = (formData: FormData) => Promise<{ error: string | null }>;

export function StudentForm({
  student,
  action,
  submitLabel,
}: {
  student?: Student;
  action: Action;
  submitLabel: string;
}) {
  const [state, formAction, pending] = useActionState<State, FormData>(
    async (_prev, formData) => action(formData),
    { error: null }
  );

  return (
    <form action={formAction} className="grid grid-cols-1 gap-4 sm:grid-cols-2">
      <div>
        <label className="mb-1 block text-sm text-ink-soft">Họ và tên *</label>
        <input
          name="full_name"
          required
          defaultValue={student?.full_name}
          className="w-full border border-paper-line bg-white px-3 py-2 outline-none focus:border-pine"
        />
      </div>
      <div>
        <label className="mb-1 block text-sm text-ink-soft">Ngày sinh</label>
        <input
          type="date"
          name="date_of_birth"
          defaultValue={student?.date_of_birth ?? ""}
          className="w-full border border-paper-line bg-white px-3 py-2 outline-none focus:border-pine"
        />
      </div>
      <div>
        <label className="mb-1 block text-sm text-ink-soft">Tên phụ huynh</label>
        <input
          name="parent_name"
          defaultValue={student?.parent_name ?? ""}
          className="w-full border border-paper-line bg-white px-3 py-2 outline-none focus:border-pine"
        />
      </div>
      <div>
        <label className="mb-1 block text-sm text-ink-soft">SĐT phụ huynh</label>
        <input
          name="parent_phone"
          defaultValue={student?.parent_phone ?? ""}
          className="w-full border border-paper-line bg-white px-3 py-2 outline-none focus:border-pine"
        />
      </div>

      {state.error && (
        <p className="sm:col-span-2 border-l-4 border-coral bg-coral/10 px-3 py-2 text-sm text-coral">
          {state.error}
        </p>
      )}

      <div className="sm:col-span-2">
        <button
          type="submit"
          disabled={pending}
          className="bg-pine px-4 py-2 font-medium text-paper transition-colors hover:bg-pine-deep disabled:opacity-60"
        >
          {pending ? "Đang lưu..." : submitLabel}
        </button>
      </div>
    </form>
  );
}

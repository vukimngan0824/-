"use server";

import { createClient } from "@/lib/supabase/server";
import { revalidatePath } from "next/cache";
import type { AttendanceStatus } from "@/lib/types";

export async function saveAttendanceForDate(
  date: string,
  entries: { student_id: string; status: AttendanceStatus }[]
) {
  const supabase = await createClient();

  const rows = entries.map((e) => ({
    student_id: e.student_id,
    date,
    status: e.status,
  }));

  const { error } = await supabase
    .from("attendance")
    .upsert(rows, { onConflict: "student_id,date" });

  if (error) {
    return { error: error.message };
  }

  revalidatePath("/diem-danh");
  revalidatePath("/hoc-sinh");
  return { error: null };
}

"use server";

import { createClient } from "@/lib/supabase/server";
import { revalidatePath } from "next/cache";

export async function addGrade(studentId: string, formData: FormData) {
  const supabase = await createClient();

  const subject = String(formData.get("subject") || "").trim() || null;
  const scoreRaw = String(formData.get("score") || "").trim();
  const score = scoreRaw ? Number(scoreRaw) : null;
  const note = String(formData.get("note") || "").trim() || null;
  const entry_date =
    String(formData.get("entry_date") || "") ||
    new Date().toISOString().slice(0, 10);

  if (!subject && !note) {
    return { error: "Cần nhập ít nhất môn học hoặc nhận xét." };
  }

  const { error } = await supabase.from("grades").insert({
    student_id: studentId,
    subject,
    score,
    note,
    entry_date,
  });

  if (error) {
    return { error: error.message };
  }

  revalidatePath(`/hoc-sinh/${studentId}`);
  return { error: null };
}

export async function deleteGrade(gradeId: string, studentId: string) {
  const supabase = await createClient();
  const { error } = await supabase.from("grades").delete().eq("id", gradeId);

  if (error) {
    return { error: error.message };
  }

  revalidatePath(`/hoc-sinh/${studentId}`);
  return { error: null };
}

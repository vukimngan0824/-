"use server";

import { createClient } from "@/lib/supabase/server";
import { revalidatePath } from "next/cache";

export async function addScheduleSlot(formData: FormData) {
  const supabase = await createClient();

  const day_of_week = Number(formData.get("day_of_week"));
  const start_time = String(formData.get("start_time") || "");
  const end_time = String(formData.get("end_time") || "");
  const subject = String(formData.get("subject") || "").trim();

  if (!day_of_week || !start_time || !end_time || !subject) {
    return { error: "Vui lòng điền đầy đủ thông tin tiết học." };
  }

  const { error } = await supabase.from("schedule_slots").insert({
    day_of_week,
    start_time,
    end_time,
    subject,
  });

  if (error) {
    return { error: error.message };
  }

  revalidatePath("/thoi-khoa-bieu");
  return { error: null };
}

export async function deleteScheduleSlot(slotId: string) {
  const supabase = await createClient();
  const { error } = await supabase
    .from("schedule_slots")
    .delete()
    .eq("id", slotId);

  if (error) {
    return { error: error.message };
  }

  revalidatePath("/thoi-khoa-bieu");
  return { error: null };
}

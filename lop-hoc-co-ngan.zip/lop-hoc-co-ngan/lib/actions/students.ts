"use server";

import { createClient } from "@/lib/supabase/server";
import { revalidatePath } from "next/cache";

export async function createStudent(formData: FormData) {
  const supabase = await createClient();

  const full_name = String(formData.get("full_name") || "").trim();
  const date_of_birth = String(formData.get("date_of_birth") || "") || null;
  const parent_name = String(formData.get("parent_name") || "").trim() || null;
  const parent_phone = String(formData.get("parent_phone") || "").trim() || null;

  if (!full_name) {
    return { error: "Vui lòng nhập họ tên học sinh." };
  }

  const { error } = await supabase.from("students").insert({
    full_name,
    date_of_birth,
    parent_name,
    parent_phone,
  });

  if (error) {
    return { error: error.message };
  }

  revalidatePath("/hoc-sinh");
  revalidatePath("/dashboard");
  return { error: null };
}

export async function updateStudent(studentId: string, formData: FormData) {
  const supabase = await createClient();

  const full_name = String(formData.get("full_name") || "").trim();
  const date_of_birth = String(formData.get("date_of_birth") || "") || null;
  const parent_name = String(formData.get("parent_name") || "").trim() || null;
  const parent_phone = String(formData.get("parent_phone") || "").trim() || null;

  if (!full_name) {
    return { error: "Vui lòng nhập họ tên học sinh." };
  }

  const { error } = await supabase
    .from("students")
    .update({ full_name, date_of_birth, parent_name, parent_phone })
    .eq("id", studentId);

  if (error) {
    return { error: error.message };
  }

  revalidatePath("/hoc-sinh");
  revalidatePath(`/hoc-sinh/${studentId}`);
  revalidatePath("/dashboard");
  return { error: null };
}

export async function deleteStudent(studentId: string) {
  const supabase = await createClient();
  const { error } = await supabase.from("students").delete().eq("id", studentId);

  if (error) {
    return { error: error.message };
  }

  revalidatePath("/hoc-sinh");
  revalidatePath("/dashboard");
  return { error: null };
}

export type Student = {
  id: string;
  full_name: string;
  date_of_birth: string | null;
  parent_name: string | null;
  parent_phone: string | null;
  access_code: string;
  created_at: string;
};

export type AttendanceStatus = "present" | "excused" | "unexcused";

export type Attendance = {
  id: string;
  student_id: string;
  date: string;
  status: AttendanceStatus;
  created_at: string;
};

export type Grade = {
  id: string;
  student_id: string;
  subject: string | null;
  score: number | null;
  note: string | null;
  entry_date: string;
  created_at: string;
};

export type ScheduleSlot = {
  id: string;
  day_of_week: number; // 2 = Thứ 2 ... 8 = Chủ nhật
  start_time: string;
  end_time: string;
  subject: string;
  created_at: string;
};

export const DAY_LABELS: Record<number, string> = {
  2: "Thứ 2",
  3: "Thứ 3",
  4: "Thứ 4",
  5: "Thứ 5",
  6: "Thứ 6",
  7: "Thứ 7",
  8: "Chủ nhật",
};

export const ATTENDANCE_LABELS: Record<AttendanceStatus, string> = {
  present: "Có mặt",
  excused: "Vắng có phép",
  unexcused: "Vắng không phép",
};

export type PublicStudentInfo = {
  full_name: string;
  parent_name: string | null;
  attendance: Attendance[];
  grades: Grade[];
  schedule: ScheduleSlot[];
};

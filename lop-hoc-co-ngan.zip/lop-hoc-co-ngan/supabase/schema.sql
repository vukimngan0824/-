-- ============================================================
-- LỚP HỌC CÔ NGÂN — Supabase schema
-- Chạy toàn bộ file này trong Supabase Dashboard > SQL Editor
-- ============================================================

create extension if not exists pgcrypto;

-- ---------- HỌC SINH ----------
create table if not exists students (
  id uuid primary key default gen_random_uuid(),
  full_name text not null,
  date_of_birth date,
  parent_name text,
  parent_phone text,
  access_code text not null unique default encode(gen_random_bytes(6), 'hex'),
  created_at timestamptz not null default now()
);

-- ---------- ĐIỂM DANH ----------
create table if not exists attendance (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references students(id) on delete cascade,
  date date not null,
  status text not null check (status in ('present', 'excused', 'unexcused')),
  created_at timestamptz not null default now(),
  unique (student_id, date)
);

-- ---------- ĐIỂM / NHẬN XÉT ----------
create table if not exists grades (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references students(id) on delete cascade,
  subject text,
  score numeric,
  note text,
  entry_date date not null default current_date,
  created_at timestamptz not null default now()
);

-- ---------- THỜI KHOÁ BIỂU (chung cho cả lớp) ----------
create table if not exists schedule_slots (
  id uuid primary key default gen_random_uuid(),
  day_of_week int not null check (day_of_week between 2 and 8), -- 2=Thứ 2 ... 8=Chủ nhật
  start_time time not null,
  end_time time not null,
  subject text not null,
  created_at timestamptz not null default now()
);

-- ============================================================
-- ROW LEVEL SECURITY
-- Nguyên tắc: chỉ giáo viên (đã đăng nhập) mới đọc/ghi trực tiếp
-- các bảng trên. Phụ huynh KHÔNG được truy cập bảng trực tiếp —
-- chỉ xem qua hàm get_public_student_info() bên dưới.
-- ============================================================

alter table students enable row level security;
alter table attendance enable row level security;
alter table grades enable row level security;
alter table schedule_slots enable row level security;

create policy "teacher full access - students" on students
  for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

create policy "teacher full access - attendance" on attendance
  for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

create policy "teacher full access - grades" on grades
  for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

create policy "teacher full access - schedule" on schedule_slots
  for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

-- ============================================================
-- HÀM DÀNH CHO PHỤ HUYNH (public, không cần đăng nhập)
-- Chỉ trả về dữ liệu của ĐÚNG 1 học sinh khớp với access_code.
-- Vì hàm chạy với quyền của người tạo (security definer), nó có
-- thể đọc dữ liệu dù RLS chặn người dùng ẩn danh đọc trực tiếp.
-- ============================================================

create or replace function get_public_student_info(code text)
returns json
language plpgsql
security definer
set search_path = public
as $$
declare
  v_student students%rowtype;
  result json;
begin
  select * into v_student from students where access_code = code;

  if not found then
    return null;
  end if;

  select json_build_object(
    'full_name', v_student.full_name,
    'parent_name', v_student.parent_name,
    'attendance', (
      select coalesce(json_agg(a order by a.date desc), '[]'::json)
      from attendance a where a.student_id = v_student.id
    ),
    'grades', (
      select coalesce(json_agg(g order by g.entry_date desc), '[]'::json)
      from grades g where g.student_id = v_student.id
    ),
    'schedule', (
      select coalesce(json_agg(s order by s.day_of_week, s.start_time), '[]'::json)
      from schedule_slots s
    )
  ) into result;

  return result;
end;
$$;

-- Cho phép người dùng ẩn danh (phụ huynh) gọi hàm này
grant execute on function get_public_student_info(text) to anon;
